<!--revolution slider -->

<div class="tp-banner-container">

	<div class="tp-banner">
		<ul>
			<li data-masterspeed="700">
				<img src="<?=base_url('assets/back/rs-plugin/assets/loader.gif') ?>" data-lazyload="<?=base_url('assets/back/img/illustrasi/slide_2.jpg') ?>" alt>
				<div class="tp-caption sl-content align-left" data-x="['left','center','center','center']" data-hoffset="20" data-y="center" data-voffset="0"  data-width="['720px','600px','500px','300px']" data-transform_in="opacity:0;s:1000;e:Power2.easeInOut;" 
				data-transform_out="opacity:0;s:300;s:1000;" data-start="400">
				<div style="margin-bottom:230px;margin-top:100px">
					<div class="sl-title">Video Pembelajaran</div>
					<p>Ayo, Pelajari video yang dimiliki oleh neon, selain videonya lengkap videonya juga mudah dipahami loh..</p>
					<a href="" class="cws-button border-radius">Mulai Pelajari <i class="fa fa-angle-double-right"></i></a>
				</div>
			</div>
		</li>



		<li data-masterspeed="700">
			<img src="<?=base_url('assets/back/rs-plugin/assets/loader.gif') ?>" data-lazyload="<?=base_url('assets/back/img/illustrasi/slide_1.jpg') ?>" alt>
			<div class="tp-caption sl-content align-right" data-x="['right','center','center','center']" data-hoffset="20" data-y="center" data-voffset="0"  data-width="['720px','600px','500px','300px']" data-transform_in="opacity:0;s:1000;e:Power2.easeInOut;" 
			data-transform_out="opacity:0;s:300;s:1000;" data-start="400">
			<div class="sl-title">Konsultasi</div>
			<p>Ada Pertanyaan? video sulit dipahami? yuuk mulai konsultasi dengan tutor neon tutornya baik-baik loh..</p>
			<a href="" class="cws-button border-radius">Konsultasi <i class="fa fa-angle-double-right"></i></a>
		</div>
	</li>



	<li data-masterspeed="700" data-transition="fade">
		<img src="<?=base_url('assets/back/rs-plugin/assets/loader.gif') ?>" data-lazyload="<?=base_url('assets/back/img/illustrasi/slide_3.jpg') ?>" alt>
		<div class="tp-caption sl-content align-center" data-x="center" data-hoffset="0" data-y="center" data-voffset="0"  data-width="['720px','600px','200px','300px']" data-transform_in="opacity:0;s:1000;e:Power2.easeInOut;" 
		data-transform_out="opacity:0;s:300;s:1000;" data-start="400">
		<div class="sl-title" style="margin-bottom:300px; ">Tryout Dan Latihan</div>
		<p><br><br>Untuk melatih pemahaman kita, yuk mulai coba latihan onlinenya..</p>
		<a href="" class="cws-button border-radius">Mulai <i class="fa fa-angle-double-right"></i></a>
	</div>

</li>
</ul>
</div>
</div>

<!-- / revolution slider