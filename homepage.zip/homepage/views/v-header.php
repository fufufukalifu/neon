	<!-- page header -->

	<header class="only-color">


		<!-- sticky menu -->

		<div class="sticky-wrapper">
			<div class="sticky-menu">
				<div class="grid-row clear-fix">
					<!-- logo -->
					<a href="<?=base_url() ?>" class="logo">
						<img src="<?=base_url('assets/back/img/logo.png')?>"  

						data-at2x="<?=base_url('assets/back/img/logo@2x.png')?>"

						>

						<h1> </h1>

					</a>

					<!-- / logo -->

					<nav class="main-nav switch-menu">

						<ul class="clear-fix">



							<li>

								<a class="service" href="#service">Layanan</a>

							</li>

							<li>

								<a class="subs" href="#subs">Interaksi</a>

							</li>

							<li>

								<a class="testimonials" href="#testimonials">Tetimonials</a>

							</li>

							<li>

								<a href="<?=base_url('index.php/register')?>">Daftar</a>

							</li>

							<li>

								<a href="<?=base_url('index.php/login')?>">Masuk</a>

							</li>

						</ul>
						<a class="menu-bar" href="#"><span class="ham"></span></a>
					</nav>

				</div>

			</div>

		</div>

		<!-- sticky menu -->

	</header>