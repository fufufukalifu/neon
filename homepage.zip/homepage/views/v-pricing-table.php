<div class="page-content">
		<div class="container">
			<main>
				<h2>Harga keanggotaan</h2>
				<p>Dibawah ini adalah pricelist untuk feature yang ada, yuk kita cek.</p>
				<div class="clear-fix">
					<div class="grid-col-row">
						<div class="grid-col grid-col-6">
							<article class="pricing-table color-3">
								<div class="header-pt clear-fix">
								<h3>Premium</h3>
								</div>
								<div class="price-pt"><sup>Rp.</sup>100.<sup>000</sup></div>
								<p>per tahun</p>
								<ul>
									<li>Video Materi Belajar</li>
									<li>Video Pembahasan Soal</li>
									<li>Latihan Soal Online</li>
									<li>Try Out Online</li>
									<li>Edu Drive</li>
									<li>Konsultasi 24 Jam</li>
									<li>Toefl Fokus</li>
									<li>Raport Online</li>
								</ul>
							</article>
						</div>

						<div class="grid-col grid-col-6">
							<article class="pricing-table color-4">
								<div class="header-pt clear-fix"><!--
								 --><h3>Free</h3>
								</div>
								<div class="price-pt"><sup>Rp</sup>0</div>
								<p>Satu minggu</p>
								<ul>
									<li>Video Pembahasan Soal</li>
									<li>Latihan Soal Online</li>
									<li>Toefl Fokus</li>
									<li>Raport Online</li>
								</ul>
							</article>
						</div>
					</div>
				</div>
			</main>
		</div>
	</div>