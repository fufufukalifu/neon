		<!-- paralax section -->

		<section class="fullwidth-background padding-section">

			<div class="grid-row clear-fix">

				<h2 class="center-text">About Us</h2>

				<div class="grid-col-row">

					<div class="grid-col grid-col-6">

						<h3>Kenapa Harus Neon</h3>

						<p>Dibawah ini adalah kenggulan dari neon..yuk cek dulu</p>

						<!-- accordions -->

						<div class="accordions">

							<!-- content-title -->

							<div class="content-title active">Video Pembelajaran Lengkap, Asyik dan Mudah dimengerti</div>

							<!--/content-title -->

							<!-- accordions content -->

							<div class="content">Puluhan ribu video bisa kalian akses. Ada 2 jenis video, video screen recording untuk kebutuhan akses low bandwith dan file kecil dan video teacher recording untuk akses dengan bandwith besar dan ukuran file yang besar, jenis ini kalian bisa lihat guru yang mengajar.</div>

							<!--/accordions content -->

							<!-- content-title -->

							<div class="content-title">Terdapat puluhan ribu latihan soal yang bisa di akses kapanpun</div>

							<!--/content-title -->

							<!-- accordions content -->

							<div class="content">Soal-soal tahun terlama dan terbaru, dari soal latihan, UN sampai dengan SBMPTN terbaru Neon hadirkan untuk kalian. Kalian bisa latihan sesuka dan sepuasnya.</div>

							<!--/accordions content -->

							<!-- content-title -->

							<div class="content-title">Bisa Konsultasi 24 jam?</div>

							<!--/content-title -->

							<!-- accordions content -->

							<div class="content">Neon menyediakan guru-guru piket yang khusus akan menjawab pertanyaan dan curhatan kalian dalam proses belajar. Rasanya kalian seperti punya mentor pribadi bersama Neon. Bisa kalian akses lewat website atau smartphone..</div>

							<!--/accordions content -->

							<!-- content-title -->

							<div class="content-title">Belajar Toefl Full Free</div>

							<!--/content-title -->

							<!-- accordions content -->

							<div class="content">Kapan lagi bisa belajar online dan dapat gratis belajar TOEFL, ya Cuma di NEON... Temen-temen bisa merasakan belajar TOEFL secara asyik dan mudah disini..</div>

							<!--/accordions content -->

						</div>

						<!--/accordions -->

						

					</div>

					<div class="grid-col grid-col-6">

						<div class="owl-carousel full-width-slider">

							<div class="gallery-item picture">

								<img src="<?=base_url('assets/back/img/about/1.jpg') ?>" data-at2x="<?=base_url('assets/img/about/1.jpg') ?>" alt>

							</div>
<div class="gallery-item picture">

								<img src="<?=base_url('assets/back/img/about/3.jpg') ?>" data-at2x="<?=base_url('assets/img/about/3.jpg') ?>" alt>

							</div>
<div class="gallery-item picture">

								<img src="<?=base_url('assets/back/img/about/2.jpg') ?>" data-at2x="<?=base_url('assets/img/about/2.jpg') ?>" alt>

							</div>
<div class="gallery-item picture">

								<img src="<?=base_url('assets/back/img/about/4.jpg') ?>" data-at2x="<?=base_url('assets/img/about/4.jpg') ?>" alt>

							</div>

							

						</div>

					</div>

				</div>

			</div>

		</section>

		<!-- paralax section -->