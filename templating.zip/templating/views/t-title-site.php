<section class="section" role="main" style="margin-top:50px;background:white;border-top:14px solid black">
	<div class="container">
		<h1 style="text-align:center;font-weight:bold">Mata Pelajaran</h1>
	</div>
</section>