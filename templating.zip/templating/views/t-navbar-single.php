    <!-- START asdasd Header -->
        <header id="header" class="navbar navbar-fixed-top">
            <div class="container">
                <div class="row">
                
                <div class="col-md-4"></div>
                
                <div class="col-md-4">
                    <div class="navbar-header">
                        <!-- Brand -->
                        <a href="#" class="mt4">
                            <span>Neon</span>
                        </a>
                        <!--/ Brand -->
                    </div>
                 </div>
                 
                <div class="col-md-4">
                     <span>User</span>
                </div>

                </div>
            </div>
            </hr>
        </header>
        <!--/ END Template Header -->
