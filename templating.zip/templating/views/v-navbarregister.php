<!-- page header -->
<header class="only-color">
    <!-- header top panel -->
    <div class="page-header-top">
    </div>
    <!-- / header top panel -->
    <!-- sticky menu -->
    <div class="sticky-wrapper">
        <div class="sticky-menu">
            <div class="grid-row clear-fix">
                <!-- logo -->
                <a href="<?=base_url()?>" class="logo">
                    <img src="<?= base_url('assets/back/img/logo.png') ?>"  data-at2x="<?= base_url('assets/back/img/logo@2x.png') ?>" alt>
                    <h1> </h1>
                </a>
                <!-- / logo -->
                <nav class="main-nav">
                    <ul class="clear-fix">
                        <li>
                            <a href="<?= base_url() ?>">Beranda</a>
                        </li>
                        <li>
                            <a href="<?= base_url('index.php/login') ?>">Masuk</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
    <!-- sticky menu -->
</header>