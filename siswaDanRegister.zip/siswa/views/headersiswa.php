<div class="page-title" style="background:#2b3036">

    <div class="grid-row">

        <h1>{judul_header2}</h1>

    </div>

</div>

<style type="text/css">
    .col-md-2{
        margin: 20px;
        padding: 0;
    }
</style>

<div class="page-content grid-row">

    <main>



        <div class="grid-col-row clear-fix" >
            
        </div>
    </div>
</main>
</div>

<hr class="divider-color">



