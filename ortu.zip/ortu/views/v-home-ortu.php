<style>
  .canvasjs-chart-credit {
   display: none;
 }
 .table th:hover{
  cursor: hand;
}

.pagination li:before{
  color:white;
}
</style>


<div class="page-title" style="background:#2b3036">
  <div class="grid-row">
    <h1>Halo <?=$this->session->userdata['USERNAME']?> , orang tua dari <?=$siswa?>  </h1>


  </div>
</div>
<!-- video random -->
<section class="padding-section" style="padding-bottom: : 0;">
  <div class="grid-row clear-fix">
    <h3 style="margin:0">HOME</h3>  

  </div>
</section>
<!-- video random -->







